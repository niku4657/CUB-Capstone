#!/usr/bin/env python

"""
Turns a collection of images and keypoint location labels into tfrecords for keypoint detection
"""

import os
import random
import queue
from lxml import etree
import threading
import tensorflow as tf


class Creator:
    """
    Turns a collection of individual images into a tfrecord.  Each input image
    is to be accompanied by keypoint (x,y) coordinate labels.
    """

    def __init__(
        self,
        imageList,
        outputFilename,
        imageSize=None,
        preserveAspectRatio=False,
        resizeMethod=tf.image.ResizeMethod.BILINEAR,
    ):
        """
        Initialize the class and create the tfrecord in one step

        Parameters:
            imageList:  list of images to process
            outputFilename:  name of the tfrecord to create

        Returns:
            None

        Result:
            A tfrecord at outputFilename

        """
        self.imageList = imageList
        self.outputFilename = outputFilename
        self.preserveAspectRatio = preserveAspectRatio
        self.resizeMethod = resizeMethod
        self.numExamples = 0
        self.labels = {}
        self.imageSize = imageSize
        self._continue = True  # Used when processing queue
        self.create()

    def create(self, shuffle=True):
        """
        Create the tfRecord from images.  Uses all of the processors on the
        machine via multiprocessing

        Parameters:
            shuffle:  Shuffle the input images before writing to tfrecord
        """
        if shuffle:
            random.shuffle(self.imageList)

        # Construct an output queue for the readers to add to
        outQ = queue.Queue(maxsize=100)

        # Get a batch of input images for each reader to process
        numReaders = os.cpu_count()
        chunks = Creator.chunk(self.imageList, numReaders)

        # Create a number of image reader/processer threads
        threads = []
        for i in range(numReaders):
            threads.append(
                threading.Thread(
                    target=self._readThread,
                    args=(
                        chunks[i],
                        outQ,
                    ),
                )
            )
            threads[-1].start()

        threads.append(threading.Thread(target=self._writeThread, args=(outQ,)))
        threads[-1].start()

        # Join reader/processor threads when complete
        for i in range(numReaders):
            threads[i].join()

        # Allow writer thread to complete
        self._continue = False

        # Join the writer thread when complete
        threads[numReaders].join()

    def _readThread(self, filenames, outQ):
        """
        Process which stores processes a list of images, storing the encoded
        images as memory streams into an output queue for processing by the
        single output writer

        Parameters:
            filenames:  list of image filenames to process
            outQ:  output queue to store processed images
        """
        for filename in filenames:
            image, keypoints = self.getKeypointSample(filename)
            outQ.put((image, keypoints))

    def _writeThread(self, inQ):
        """
        Process which examines a queue for images and labels and records them in the tfrecord

        Parameters:
            inQ:  queue of images and labels to write to tfrecord
        """
        with tf.io.TFRecordWriter(self.outputFilename) as writer:
            while self._continue or not inQ.empty():
                try:
                    image, keypoints = inQ.get(timeout=1)
                    ex = self.createExample(image, keypoints)
                    writer.write(ex.SerializeToString())
                    self.numExamples += 1
                except queue.Empty:
                    pass

    @staticmethod
    def createExample(image, keypoints):
        """
        Encodes an image and keypoints into a tensorflow training example
        """
        feature = {
            "image": Creator.bytesFeature(image),
            "keypoints": Creator.keypointListFeature(keypoints),
        }
        return tf.train.Example(features=tf.train.Features(feature=feature))

    def processImage(self, filename):

        size = self.imageSize

        with open(filename, "rb") as imgFile:
            image = tf.io.decode_image(
                imgFile.read(), channels=size[2], expand_animations=False
            )
        if (size[0], size[1]) != (0, 0):
            image = tf.image.resize(
                image,
                (size[0], size[1]),
                method=self.resizeMethod,
                preserve_aspect_ratio=self.preserveAspectRatio,
            )
            image = tf.cast(image, tf.uint8)
        return tf.image.encode_png(image)

    def getKeypointSample(self, filename, relativePath=True):
        """
        Read in an image file and its corresponding keypoints

        Parameters:
            filename:  filename of the image to read

        Returns:
            A BytesIO() stream of the image and the keypoints for the image
        """

        with open(filename) as f:
            # Parse the xml
            tree = etree.parse(f)
            imageFilename = tree.xpath("filename")[0].text

            # Get the absolute path from the relative one
            if relativePath:
                imageFilename = os.path.join(os.path.dirname(filename), imageFilename)

            img = self.processImage(imageFilename)
            # Get sizes to normalize x,y input in pixels to 0,1
            width = int(tree.find("size/width").text)
            height = int(tree.find("size/height").text)

            points = []
            count = 0
            for point in tree.find("points"):

                x = float(point.find("x").text)
                y = float(point.find("y").text)
                points.append(x / width)
                points.append(y / height)

                self.labels[str(point.find("name").text)] = count
                count += 1

            return (img, points)

    @staticmethod
    def chunk(lst, num):
        """
        Take a list lst and convert it into a list of num lists, with each of
        num chunks containing an approximately equal number of items
        """
        div, mod = divmod(len(lst), num)
        return list(
            lst[i * div + min(i, mod) : (i + 1) * div + min(i + 1, mod)]
            for i in range(num)
        )

    @staticmethod
    def bytesFeature(value):
        """
        Returns a bytes_list from a string / byte
        """
        if isinstance(value, type(tf.constant(0))):
            value = (
                value.numpy()
            )  # BytesList won't unpack a string from an EagerTensor.
        return tf.train.Feature(bytes_list=tf.train.BytesList(value=[value]))

    @staticmethod
    def keypointListFeature(array):
        """"""
        if isinstance(array, type(list)):
            array = np.array(array)
        return tf.train.Feature(float_list=tf.train.FloatList(value=array))
