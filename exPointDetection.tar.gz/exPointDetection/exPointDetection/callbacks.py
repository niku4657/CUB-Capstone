#!/usr/bin/env python

import numpy as np
from datetime import datetime
from tensorflow.keras.callbacks import Callback


class MSECallback(Callback):
    """
    Calculates pixel distance metrics and prints them out during training
    """

    def __init__(
        self,
        model,
        testDataset,
        imageShape,
        labelMap,
        everyNEpochs=10,
        description="",
        model_filename="model",
        networkType="inception_v3",
    ):
        """
        Initialization

        everyNEpochs:  Run MSE calculation every N epochs
        description:  When printing results, include this description of MSE
        saveBestNetworkAs:  If a string, save the network according to its filestem
        """
        super().__init__()
        self.testDataset = testDataset
        self.imageShape = imageShape
        self.everyNEpochs = everyNEpochs
        self.description = description
        self.model = model
        currentDate = datetime.now()
        self.model_filename = model_filename
        self.networkType = networkType
        self.lowestError = 999999999
        self.labelMap = labelMap

    def on_epoch_end(self, epoch, logs=None):
        """
        Keras calls this when it is finished with an epoch automatically.  We
        simply tell it what to do
        """
        if epoch % self.everyNEpochs != 0:
            return

        predictions = []
        labels = []
        num_points = 0
        wh = (self.imageShape[1], self.imageShape[0])
        # Get the labels and prediction for each example in the validation set
        for batch in self.testDataset.dataset.as_numpy_iterator():
            yPred = self.model.predict_on_batch(batch[0])
            predictions.append(yPred)

            for image, keypoint_list in zip(batch[0], batch[1]):
                keypoint_list = np.reshape(keypoint_list, (-1, 2))
                num_points = keypoint_list.shape[0]
                keypoint_list = np.reshape(keypoint_list, (1, -1))
                labels.append(keypoint_list)

        # Change from list to numpy matrix
        labels = np.concatenate(labels, axis=0)
        predictions = np.concatenate(predictions, axis=0)

        # Calculate pixel distances from individual x, y error
        distance = (labels - predictions) ** 2

        distance = distance.reshape(distance.shape[0] * distance.shape[1] // 2, 2)
        distance = np.sum(distance, axis=1)
        distance = np.sqrt(distance)

        meanError = distance.mean()
        rmsError = np.sqrt((distance ** 2).mean())

        print("\n%s Mean Error: %0.4f" % (self.description, meanError))
        print("%s Root Mean Squared Error: %0.4f" % (self.description, rmsError))

        point_distances = distance.reshape(labels.shape[0], num_points)
        point_mse = point_distances.mean(axis=0)
        point_rmse = np.sqrt((point_distances ** 2).mean(axis=0))

        print("-----------------------")
        for i in range(num_points):
            print(
                "%s Point [%s] Mean Error: %0.4f"
                % (self.description, self.labelMap[i], point_mse[i])
            )
            print(
                "%s Point [%s] Root Mean Squared Error: %0.4f"
                % (self.description, self.labelMap[i], point_rmse[i])
            )
        print("-----------------------")

        if rmsError < self.lowestError:
            self.lowestError = rmsError
            self.model.save(self.model_filename + ".h5")
