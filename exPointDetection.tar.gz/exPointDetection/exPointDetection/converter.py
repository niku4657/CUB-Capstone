#!/usr/bin/env python

"""
Convert semantic segmentation models to different formats
"""

import json
import shutil

import tensorflow as tf
from tensorflow.python.compiler.tensorrt import trt_convert

from exPointDetection.dataset import Dataset
from exPointDetection.creator import Creator


class ModelConverter:
    """
    Convert from one model format to another
    """

    def __init__(self, modelFilename):
        self.modelFilename = modelFilename
        self.infoFilename = self.getInfoFile()
        self.modelFilestem = self.getModelFilestem()
        self.model = None
        self.preprocessorType = None
        self.shape = None
        self.datasetFunction = None

        self.loadModel()

    def loadModel(self):
        """
        Load model architecture and weights
        """
        self.model = tf.keras.models.load_model(self.modelFilename)
        with open(self.infoFilename) as infoFile:
            j = json.loads(infoFile.read())
            self.preprocessorType = j["preprocessor_type"]

        _, width, height, channels = self.model.layers[0].get_config()[
            "batch_input_shape"
        ]
        self.shape = (width, height, channels)

    def getInfoFile(self):
        """Returns the location of the info file, for keras or savedmodel"""
        if self.modelFilename.split(".")[-1] == "h5":
            return ".".join(self.modelFilename.split(".")[0:-1]) + ".json"
        return self.modelFilename + "/assets/info.json"

    def isKeras(self):
        """Returns true if file appears to be keras h5"""
        return self.modelFilename.split(".")[-1] == "h5"

    def isTflite(self):
        """Returns true if file appears to be tflite"""
        return self.modelFilename.split(".")[-1] == "tflite"

    def getModelFilestem(self):
        """Returns the basename of the keras or savedmodel given"""
        if self.isKeras():
            return ".".join(self.modelFilename.split(".")[0:-1])
        return self.modelFilename

    def setDatasetFunction(self, images):
        """
        Set up a dataset function for reading calibration images in a format
        tflite can digest
        """
        preprocessFunction = Unet.getPreprocessor(self.preprocessorType)

        # Construct the training set
        representativeDataset = (
            Dataset()
            .fromCreator(Creator(images, "calibration.tfrecord", size=self.shape))
            .load(1, preprocessFunction, isTraining=False)
        )

        def representativeDatasetGen():
            """
            Pull images out of the dataset.  Masks not needed
            """
            for image, _ in representativeDataset.dataset:
                yield [image]

        self.datasetFunction = representativeDatasetGen

    def convertTrt(self, precision, rtMinSegmentSize):
        """Convert from SavedModel to SavedModel+TRT"""

        if self.isKeras() or self.isTflite():
            raise "Model conversion to RT requires SavedModel"

        # pylint: disable=no-member
        params = trt_convert.DEFAULT_TRT_CONVERSION_PARAMS
        params = params._replace(
            precision_mode=precision,
            minimum_segment_size=rtMinSegmentSize,
        )

        converter = trt_convert.TrtGraphConverterV2(
            input_saved_model_dir=self.modelFilestem,
            conversion_params=params,
        )
        converter.convert(self.datasetFunction)

        # TODO: Fix broken tensorflow build function when function is no
        # longer broken
        # converter.build(self.datasetFunction)
        converter.save(self.modelFilestem + ".trt")

        shutil.copyfile(self.infoFilename, self.modelFilestem + ".trt/assets/info.json")

    def convertTflite(self, precision):
        """Convert from keras to tflite"""

        if not self.isKeras():
            raise "Model conversion to tflite requires keras source"

        # https://www.tensorflow.org/lite/performance/post_training_quantization
        converter = tf.lite.TFLiteConverter.from_keras_model(self.model)
        if precision == "FP16":
            converter.optimizations = [tf.lite.Optimize.DEFAULT]
            converter.target_spec.supported_types = [tf.float16]
        elif precision == "INT8":
            # Without reprsentative dataset: dynamic range quantization
            # With representative dataset: full integer quantization
            #    (except for input/output layer)
            converter.optimizations = [tf.lite.Optimize.DEFAULT]
            if self.datasetFunction:
                converter.target_spec.supported_types = [tf.uint8]
                converter.representative_dataset = self.datasetFunction
        convertedModel = converter.convert()
        with open(self.modelFilestem + ".tflite", "wb") as modelFile:
            modelFile.write(convertedModel)

    def convertSavedModel(self):
        """Convert from keras to saved model"""

        if not self.isKeras():
            raise "Model conversion to tflite requires keras source"

        self.model.save(self.modelFilestem, save_format="tf")
        shutil.copyfile(self.infoFilename, self.modelFilestem + "/assets/info.json")
