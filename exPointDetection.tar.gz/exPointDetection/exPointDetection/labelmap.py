"""
Handles classification network label maps of class names and integers
"""


class BidirectionalDictionary(dict):
    """
    Simple bidirectional dictionary for cases where A -> B and B -> A while
    maintaining standard python dictionary semantics

    Notes:  code pretty much pulled directly from
            https://stackoverflow.com/questions/1456373/two-way-reverse-map#
    """

    def __init__(self, seq=None, **kwargs):
        """
        Allows passing in a dictionary directly (e.g. BidrectionalDictionary({1:'person'}))
        """

        if seq is None:
            super().__init__(**kwargs)
        else:
            super().__init__(seq, **kwargs)

        for key, val in seq.items():
            dict.__setitem__(self, val, key)
        for key, val in kwargs.items():
            dict.__setitem__(self, val, key)

    def __setitem__(self, key, value):
        """
        Allows setting value in dictionary fashion (e.g. bd['person'] = 1)
        """

        # Remove any previous connections with these values
        if key in self:
            del self[key]
        if value in self:
            del self[value]

        dict.__setitem__(self, key, value)
        dict.__setitem__(self, value, key)

    def __delitem__(self, key):
        """
        Each delete call must delete both forward and inverse connections
        """
        dict.__delitem__(self, self[key])
        dict.__delitem__(self, key)

    def __len__(self):
        """
        Returns the number of actual connections
        """
        return dict.__len__(self) // 2


class LabelMap(BidirectionalDictionary):
    """
    LabelMap constructs a bidirectional dictionary that can be used for
    translation of class labels to integers and vice verca
    """

    def reduce(self):
        """
        Reduce the bidirectional dictionary to a mapping from class labels to
        integers only.

        This is useful for writing the label map to json.  JSON is limited to
        writing to strings as the dictionary keys.
        """
        return {k: self[k] for k in self if not isinstance(k, int)}
