#!/usr/bin/env python

"""
Create a dataset that can be used as tensorflow training or test dataset from a
tfrecord file for semantic segmentation.
"""

import numpy as np
import tensorflow as tf


class Dataset:
    """
    Used to feed data into tensorflow.  Stores a variety of information about
    the underlying dataset, with methods to get at that information from the
    tfrecord
    """

    def __init__(self):
        """
        Initializes a blank dataset with no information
        """
        self.recordFilename = None
        self.numExamples = None
        self.imageSize = None
        self.dataset = None
        self.batchSize = None
        self.labels = {}
        self.numPoints = 0

    def fromCreator(self, creator):
        """
        Store information from a Creator class which is sufficient to parse and
        load data from a tfrecord.

        Parameters:
            creator:  The creator class to initialize this class with

        Returns:
            self, for convenience

        Note:
            The creator may store an image size if the user has overridden it,
            but this is not guaranteed
        """
        self.recordFilename = creator.outputFilename
        self.labels = creator.labels
        self.numExamples = creator.numExamples
        return self

    # pylint: disable=too-many-arguments
    def load(
        self,
        batchSize,
        preprocessFunction,
        isTraining=True,
        bufferSize=1000,
        augOpts=None,
    ):
        """
        Begin processing of the tfrecord

        Parameters:
            batchSize: number of items to place in each batch
            isTraining:  will this dataset be used for training
            bufferSize:  when shuffling, how many examples to shuffle between
            augOpts:  An optional class containing augmentatation options

        Returns:
            self, for convenience
        """

        @tf.function
        def parse(example):
            """
            Parse an example from the tfrecord, applying any preprocessing function
            and returning both the image and the keypoint labels

            Parameters:
                example: an input Tensor from the TFRecordDataset

            Returns:
                image tensor and keypoint tensor
            """
            features = tf.io.parse_single_example(
                example,
                features={
                    "image": tf.io.FixedLenFeature([], tf.string),
                    "keypoints": tf.io.FixedLenSequenceFeature(
                        [], tf.float32, allow_missing=True
                    ),
                },
            )

            image = tf.image.decode_jpeg(features["image"])
            image = tf.cast(image, tf.float32)
            keypoints = features["keypoints"]

            if augOpts:
                if "hFlip" in augOpts and tf.random.uniform(()) > augOpts["hFlip"]:
                    image = tf.image.flip_left_right(image)
                    keypoints = tf.reshape(keypoints, [-1, 2])
                    tf.math.multiply(keypoints, tf.constant([-1.0, 1.0]))
                    tf.math.add(keypoints, tf.constant([1.0, 0.0]))
                    keypoints = tf.reshape(keypoints, [-1, 1])

                if "vFlip" in augOpts and tf.random.uniform(()) > augOpts["vFlip"]:
                    image = tf.image.flip_up_down(image)
                    keypoints = tf.reshape(keypoints, [-1, 2])
                    tf.math.multiply(keypoints, tf.constant([1.0, -1.0]))
                    tf.math.add(keypoints, tf.constant([0.0, 1.0]))
                    keypoints = tf.reshape(keypoints, [-1, 1])

                if "randomJpegQuality" in augOpts:
                    image = tf.image.random_jpeg_quality(
                        image, **augOpts["randomJpegQuality"]
                    )
                if "randomBrightness" in augOpts:
                    image = tf.image.random_brightness(
                        image, **augOpts["randomBrightness"]
                    )
                if "randomContrast" in augOpts:
                    image = tf.image.random_contrast(
                        image,
                        **augOpts["randomContrast"],
                    )
                if "randomSaturation" in augOpts:
                    image = tf.image.random_saturation(
                        image,
                        **augOpts["randomSaturation"],
                    )
                if "randomHue" in augOpts:
                    image = tf.image.random_hue(image, **augOpts["randomHue"])
                # TODO SCALE AND ROTATE KEYPOINTS
                image = tf.clip_by_value(image, 0.0, 255.0)

            image = preprocessFunction(image)

            return image, keypoints

        self.batchSize = batchSize
        self.dataset = tf.data.TFRecordDataset(self.recordFilename)
        self.dataset = self.dataset.map(
            parse, num_parallel_calls=tf.data.experimental.AUTOTUNE
        )
        self.numPoints = self.getNumPoints()
        if isTraining:
            self.dataset = self.dataset.shuffle(bufferSize).batch(
                batchSize, drop_remainder=True
            )
            self.dataset = self.dataset.prefetch(
                buffer_size=tf.data.experimental.AUTOTUNE
            )
        else:
            self.dataset = self.dataset.batch(batchSize, drop_remainder=True)
        return self

    def getNumExamples(self):
        """
        Determine how many examples are in the tfrecord.  Caches the result for
        later use if the function is called again

        Returns:
            Number of examples in tfrecord
        """
        if self.numExamples:
            return self.numExamples
        self.numExamples = sum(1 for _ in tf.data.TFRecordDataset(self.recordFilename))
        return self.numExamples

    def getImageSize(self):
        """
        Returns the image size in the tfrecord.  Caches the result for later
        use if the function is called again

        Returns:
            Image size as H, W, C
        """
        if self.imageSize:
            return self.imageSize
        for image, _ in self.dataset.take(1):
            shape = tf.shape(image).numpy()
            self.imageSize = (shape[1], shape[2], shape[3])
        return self.imageSize

    def getNumPoints(self):
        """"""
        for _, label in self.dataset.take(1):
            numPoints = tf.shape(label).numpy() // 2
        return numPoints
