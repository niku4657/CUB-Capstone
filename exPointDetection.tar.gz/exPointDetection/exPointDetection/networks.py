#!/usr/bin/env python

"""
TF Network components for use in transfer learning
"""

import tensorflow as tf
import numpy as np

from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam, SGD

from tensorflow.keras.applications import (
    inception_resnet_v2,
    resnet50,
    xception,
    vgg16,
    vgg19,
    mobilenet,
    inception_v3,
    mobilenet_v2,
    nasnet,
    EfficientNetB0,
    EfficientNetB1,
    EfficientNetB2,
    EfficientNetB3,
    EfficientNetB4,
    EfficientNetB5,
    EfficientNetB6,
    EfficientNetB7,
)


class KeypointNetworks:
    """"""

    @staticmethod
    def getNetworkTypes():
        """"""
        networkTypes = [
            "xception",
            "vgg16",
            "vgg19",
            "resnet50",
            "inceptionv3",
            "inceptionresnetv2",
            "mobilenet",
            "nasnetmobile",
            "mobilenetv2",
            "EfficientNetB0",
            "EfficientNetB1",
            "EfficientNetB2",
            "EfficientNetB3",
            "EfficientNetB4",
            "EfficientNetB5",
            "EfficientNetB6",
            "EfficientNetB7",
        ]
        return networkTypes

    @staticmethod
    def getDefaultImageSize(networkType):
        """
        Returns the default image size from the docs
        """
        sizes = {
            "resnet50": (224, 224, 3),
            "xception": (299, 299, 3),
            "mobilenet": (224, 224, 3),
            "mobilenetv2": (224, 224, 3),
            "inceptionv3": (299, 299, 3),
            "vgg16": (224, 224, 3),
            "vgg19": (224, 224, 3),
            "nasnetmobile": (224, 224, 3),
            "inception_resnet_v2": (299, 299, 3),
            "EfficientNetB0": (224, 224),
            "EfficientNetB1": (240, 240),
            "EfficientNetB2": (260, 260),
            "EfficientNetB3": (300, 300),
            "EfficientNetB4": (380, 380),
            "EfficientNetB5": (456, 456),
            "EfficientNetB6": (528, 528),
            "EfficientNetB7": (600, 600),
        }
        return sizes[networkType]

    @staticmethod
    def getPreprocessor(networkType):
        """
        Returns the tensorflow function that should be used to preprocess input
        images given the specified network type

        Parameters:
            networkType:  the keras encoder network architecture to use

        Returns:
            The tensorflow function
        """
        preprocessors = {
            "resnet50": tf.keras.applications.resnet50.preprocess_input,
            "xception": tf.keras.applications.xception.preprocess_input,
            "mobilenet": tf.keras.applications.mobilenet.preprocess_input,
            "mobilenetv2": tf.keras.applications.mobilenet_v2.preprocess_input,
            "inceptionv3": tf.keras.applications.inception_v3.preprocess_input,
            "vgg16": tf.keras.applications.vgg16.preprocess_input,
            "vgg19": tf.keras.applications.vgg19.preprocess_input,
            "nasnetmobile": tf.keras.applications.nasnet.preprocess_input,
            "inception_resnet_v2": tf.keras.applications.inception_resnet_v2.preprocess_input,
            "EfficientNetB0": tf.keras.applications.efficientnet.preprocess_input,
            "EfficientNetB1": tf.keras.applications.efficientnet.preprocess_input,
            "EfficientNetB2": tf.keras.applications.efficientnet.preprocess_input,
            "EfficientNetB3": tf.keras.applications.efficientnet.preprocess_input,
            "EfficientNetB4": tf.keras.applications.efficientnet.preprocess_input,
            "EfficientNetB5": tf.keras.applications.efficientnet.preprocess_input,
            "EfficientNetB6": tf.keras.applications.efficientnet.preprocess_input,
            "EfficientNetB7": tf.keras.applications.efficientnet.preprocess_input,
        }
        return preprocessors[networkType]

    @staticmethod
    def getNetwork(networkType, width, height, num_points):
        """
        Load a network from Keras stock api
        """
        if networkType == "resnet50":
            baseModel = resnet50.ResNet50(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "inceptionresnetv2":
            baseModel = inception_resnet_v2.InceptionResNetV2(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "xception":
            baseModel = xception.Xception(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "mobilenet":
            baseModel = mobilenet.MobileNet(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "mobilenetv2":
            baseModel = mobilenet_v2.MobileNetV2(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "inceptionv3":
            baseModel = inception_v3.InceptionV3(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "nasnetlarge":
            baseModel = nasnet.NASNetLarge(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "nasnetmobile":
            baseModel = nasnet.NASNetMobile(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "vgg16":
            baseModel = vgg16.VGG16(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "vgg19":
            baseModel = vgg19.VGG19(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "EfficientNetB0":
            baseModel = EfficientNetB0(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "EfficientNetB1":
            baseModel = EfficientNetB1(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "EfficientNetB2":
            baseModel = EfficientNetB2(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "EfficientNetB3":
            baseModel = EfficientNetB3(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "EfficientNetB4":
            baseModel = EfficientNetB4(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "EfficientNetB5":
            baseModel = EfficientNetB5(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "EfficientNetB6":
            baseModel = EfficientNetB6(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        elif networkType == "EfficientNetB7":
            baseModel = EfficientNetB7(
                include_top=False,
                weights="imagenet",
                input_shape=(height, width, 3),
                pooling="avg",
            )
        else:
            raise Exception("Network type not found")

        outputs = Dense(2 * num_points, name="Logits")(baseModel.output)
        model = Model(baseModel.inputs, outputs)
        model.baseModelLayers = baseModel.layers
        return model

    def fromDataset(self, dataset, networkType):
        """
        Store information from a dataset class which contains enough info for
        a default network architecture

        Parameters:
            dataset:  The dataset to initialize the class with

        Returns:
            self, for convenience
        """
        self.inputShape = dataset.getImageSize()
        self.batchSize = dataset.batchSize
        self.dataset = dataset
        self.model = KeypointNetworks.getNetwork(
            networkType, self.inputShape[1], self.inputShape[0], dataset.numPoints
        )
        return self

    def train(self, numEpochs, learningRate=None, testDataset=None, opt=Adam, **kwargs):
        """
        Performs the training of the unet architecture

        Parameters:
            numEpochs:  number of epochs to train
            learningRate:  learning rate to apply (use default if not specified)
            testDataset:  an optional test/validation dataset
            kwargs:  kwargs for calling tf.keras.model.fit

        Returns:
            The output of model.fit

        Note:
            This used to have SparseMeanIOU as a metric, but doing so resulted
            in the model requiring that class when reading it in for testing.
            It is instead included only in evaluate() where it may be used for
            validation, but is not output together with the model.
        """
        # Model is not being defined anywhere...
        self.model.compile(loss="mean_squared_error", optimizer=opt(lr=learningRate))

        return self.model.fit(
            self.dataset.dataset,
            epochs=numEpochs,
            validation_data=testDataset.dataset if testDataset else None,
            **kwargs,
        )

    def evaluate(self, dataset, labelMap):
        """
        Evaluates the accuracy & loss of the model on the dataset

        Parameter:
            dataset:  input dataset to evaluate accuracy on

        Returns:
            The output of tf keras model.evaluate()
        """

        self.model.compile(loss="mean_squared_error")

        predictions = []
        labels = []
        num_points = 0

        # Get the labels and prediction for each example in the validation set
        for batch in dataset.dataset.as_numpy_iterator():
            yPred = self.model.predict_on_batch(batch[0])
            predictions.append(yPred)

            for image, keypoint_list in zip(batch[0], batch[1]):
                keypoint_list = np.reshape(keypoint_list, (-1, 2))
                num_points = keypoint_list.shape[0]
                keypoint_list = np.reshape(keypoint_list, (1, -1))
                labels.append(keypoint_list)

        # Change from list to numpy matrix
        labels = np.concatenate(labels, axis=0)
        predictions = np.concatenate(predictions, axis=0)

        # Calculate pixel distances from individual x, y error
        distance = (labels - predictions) ** 2

        distance = distance.reshape(distance.shape[0] * distance.shape[1] // 2, 2)
        distance = np.sum(distance, axis=1)
        distance = np.sqrt(distance)

        meanError = distance.mean()
        rmsError = np.sqrt((distance ** 2).mean())

        print("Validation Mean Error: %0.4f" % (meanError))
        print("Validation Root Mean Squared Error: %0.4f" % (rmsError))

        point_distances = distance.reshape(labels.shape[0], num_points)
        point_mse = point_distances.mean(axis=0)
        point_rmse = np.sqrt((point_distances ** 2).mean(axis=0))

        print("-----------------------")
        for i in range(num_points):
            print(
                "Validation Point [%s] Mean Error: %0.4f" % (labelMap[i], point_mse[i])
            )
            print(
                "Validation Point [%s] Root Mean Squared Error: %0.4f"
                % (labelMap[i], point_rmse[i])
            )
        print("-----------------------")
        self.model.evaluate(dataset.dataset)

    def setAllTrainable(self):
        """
        Sets all layers in the network to trainable
        """
        for layer in self.model.layers:
            layer.trainable = True

    def setOnlyLastLayerTrainable(self):
        """
        Sets all layers in the network to trainable
        """
        for layer in self.model.baseModelLayers:
            layer.trainable = False

    def save(self, filename):
        """
        Saves network to disk

        Parameters:
            filename:  file to save network as
        """
        self.model.save(filename)

    def load(self, filename):
        """
        Loads network from disk

        Parameters:
            filename:  file to read network from

        Returns:
            self, for convenience
        """
        self.model = tf.keras.models.load_model(filename, compile=False)
        _, width, height, channels = self.model.layers[0].get_config()[
            "batch_input_shape"
        ]
        self.inputShape = (width, height, channels)
        return self
