#!/usr/bin/env python

"""
Module for augmentation options
"""


import json


class AugmentationOptions(dict):
    """
    Augmentation options
    """

    def loadDefault(self, level=0):
        """
        Automatically set some minimally invasive defaults

        Input:
            level:  used to control the amount of augmentation

        Returns:
            self, for convenience
        """
        if level == 1:
            self["hFlip"] = 0.5
        if level == 2:
            self["hFlip"] = 0.5
            self["vFlip"] = 0.5
        if level == 5:
            self["hFlip"] = 0.5
            self["vFlip"] = 0.5
            self["randomBrightness"] = {
                "max_delta": 0.1,
            }
            self["randomContrast"] = {
                "lower": 0.9,
                "upper": 1.0,
            }
            self["randomSaturation"] = {
                "lower": 0.75,
                "upper": 1.25,
            }
            self["randomHue"] = {
                "max_delta": 0.1,
            }
        if level == 10:
            self["hFlip"] = 0.5
            self["vFlip"] = 0.5
            self["randomBrightness"] = {
                "max_delta": 0.2,
            }
            self["randomContrast"] = {
                "lower": 0.8,
                "upper": 1.0,
            }
            self["randomSaturation"] = {
                "lower": 0.5,
                "upper": 2.0,
            }
            self["randomHue"] = {
                "max_delta": 0.2,
            }
            self["randomJpegQuality"] = {
                "min_jpeg_quality": 90,
                "max_jpeg_quality": 100,
            }
        return self

    def loadJson(self, jsonFilename):
        """
        Load augmentation options from disk

        Parameters:
            jsonFilename:  location to read json from

        Returns:
            self, for convenience
        """
        with open(jsonFilename) as jsonFile:
            self.update(json.load(jsonFile))
        return self

    def saveJson(self, jsonFilename):
        """
        Save augmentation options to disk

        Parameters:
            jsonFilename:  location to write json to
        """
        with open(jsonFilename, "w") as jsonFile:
            jsonFile.write(json.dumps(self))
