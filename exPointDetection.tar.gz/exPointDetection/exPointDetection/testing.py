#!/usr/bin/env python3

"""
Test/Infer using a semantic segmentation network
"""

import os
import cgi
import json
import datetime
from io import BytesIO
from http.server import BaseHTTPRequestHandler, HTTPServer

import tensorflow as tf

from tensorflow.keras.models import load_model

# pylint: disable=no-name-in-module,import-error
from tensorflow.python.framework import convert_to_constants

from exPointDetection.networks import KeypointNetworks
from exPointDetection.labelmap import LabelMap


class WebHandler(BaseHTTPRequestHandler):
    """
    Class for constructing a small webserver that serves up a tensorflow
    classification api neural network
    """

    tft = None
    port = 8080

    # pylint: disable=invalid-name
    def log_message(self, _, *args):
        """
        Override the default logging to stdout
        """
        return

    # pylint: disable=invalid-name
    def do_GET(self):
        """
        Provides a small web page to the user
        """

        if self.path == "/":
            response = """<html>
  <body>
    <h1>Neural Network Tester</h1>
    <h2>testDetector.py</h2>
    <form id="uploadbanner" enctype="multipart/form-data" method="post" action="#">
      <input id="fileupload" name="file" type="file" /><BR>
      <input type="submit" value="submit" id="submit" />
    </form>
  </body>
</html>"""
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(response.encode())

        elif self.path == "/points":
            response = json.dumps(WebHandler.tft.labelMap.reduce())
            self.send_response(200)
            self.send_header("Content-type", "application/json")
            self.end_headers()
            self.wfile.write(response.encode())

        else:
            self.send_error(404)

    # pylint: disable=invalid-name
    def do_POST(self):
        """
        Handle a POST request
        """

        if self.path == "/":
            form = cgi.FieldStorage(
                fp=self.rfile,
                headers=self.headers,
                environ={
                    "REQUEST_METHOD": "POST",
                    "CONTENT_TYPE": self.headers["Content-Type"],
                },
            )
            j = WebHandler.tft.doDetection(form["file"].file.read())
            self.response(j)

        elif self.path == "/shutdown":
            self.send_response(200)
            self.wfile.flush()
            self.wfile.close()
            exit(0)

        else:
            self.send_error(404)

    # pylint: disable=invalid-name
    def do_PUT(self):
        """
        Handle a PUT request
        """

        length = int(self.headers["Content-Length"])
        data = self.rfile.read(length)
        j = WebHandler.tft.doDetection(data)
        self.response(j)

    def response(self, response, status=200):
        """
        Send response to client
        """

        self.send_response(status)
        self.send_header("Content-type", "text/json")
        self.send_header("Content-length", len(response))
        self.end_headers()
        self.wfile.write(response.encode())


class NetworkTester:
    """
    Class which performs inference on models trained with the point detector
    """

    def __init__(self):
        self._loadedModel = None  # This is for spacekeeping only
        self.model = None
        self.filestem = None
        self.inputShape = None
        self.preprocessor = None
        self.labelMap = None
        self.detectionTime = None
        self.processingTime = None
        self.visualization = False
        self.outputType = None

    def readImageDataAsArray(self, imageData):
        """
        Convert a PIL image into a numpy array.  Also resizes input image.

        Input:
            Input PIL image

        Returns:
            Image data as a 1,H,W,C numpy array
        """
        if self.inputShape:
            # Resize image shape. Note: shape is NHWC, and resize expects WH
            i = imageData.resize(self.inputShape[0:2][::-1], Image.NEAREST)
        else:
            i = imageData
        i = np.array(i)
        i = np.expand_dims(i, axis=0)
        return i

    def loadSavedModel(self):
        """
        Load model architecture and weights

        Returns nothing
        """

        # Note:  The loadedModel must remain in memory throughout this process
        # or else things will fail.  It must be separate from the call to
        # signedModel, or else it will drop out of memory.
        loadedModel = tf.saved_model.load(self.filestem, tags=[tf.saved_model.SERVING])
        signedModel = loadedModel.signatures[
            tf.saved_model.DEFAULT_SERVING_SIGNATURE_DEF_KEY
        ]

        # Get information about the output shapes from the model
        self.inputShape = signedModel.inputs[0].shape[1:]  # (Width, Height, Channels)

        # pylint: disable=no-member
        self.model = convert_to_constants.convert_variables_to_constants_v2(signedModel)

        # Load preprocessor/colormap from disk
        with open(self.filestem + "/assets/info.json") as infoFile:
            j = json.loads(infoFile.read())
            self.preprocessor = KeypointNetworks.getPreprocessor(j["preprocessor_type"])
            self.labelMap = LabelMap(j["label_map"])
            self.multiLabel = "Logits" in signedModel.output_shapes.keys()

    def doJson(self, yPred, imagePath=None):
        """
        Create json for output after inference
        """

        # Create the output json
        d = {"image_point_detection": {}}
        d["image_point_detection"]["detections"] = dict()
        d["image_point_detection"]["processing_time_ms"] = self.processingTime
        d["image_point_detection"]["detection_time_ms"] = self.detectionTime

        keypoints = []
        for i in range(self.numPoints):
            x = float(yPred[i * 2])
            y = float(yPred[i * 2 + 1])

            if self.outputType == "pixel":
                x = x * self.shape[2]
                y = y * self.shape[1]

            pointLabel = self.labelMap[i]
            keypoints.append({"id": i, "name": pointLabel, "x": x, "y": y})

        d["image_point_detection"]["detections"] = keypoints

        if imagePath:
            d["image_point_detection"]["filename"] = os.path.split(imagePath)[1]

        return json.dumps(d, indent=4)

    def doDetection(self, imageData, imagePath=None):
        """
        Performs the detection and writes output to desired locations
        """

        # Obtain x,y coordinates of prediction on preprocessed image
        procStartTime = datetime.datetime.now()
        arr = tf.image.decode_jpeg(imageData)
        arr = tf.expand_dims(arr, 0)
        self.shape = arr.shape
        arr = tf.image.resize(arr, self.inputShape[0:2][::-1])
        detStartTime = datetime.datetime.now()
        yPred = self.model(self.preprocessor(arr))[0].numpy()
        self.numPoints = yPred.shape[1] // 2
        self.detectionTime = (
            datetime.datetime.now() - detStartTime
        ).total_seconds() * 1000
        self.processingTime = (
            datetime.datetime.now() - procStartTime
        ).total_seconds() * 1000

        j = self.doJson(tf.squeeze(yPred), imagePath)

        return j

    def run(self, filenames=None, server=False):
        """
        Run the neural network tester on either a collection of images or as a
        web server
        """

        self.loadSavedModel()
        if not server:
            for imagePath in filenames:
                with open(imagePath, "rb") as imageFile:
                    try:
                        jsonString = self.doDetection(imageFile.read(), imagePath)
                        with open(imagePath + ".output.json", "wt") as jsonFile:
                            jsonFile.write(jsonString + "\n")
                    except:
                        pass
        else:
            WebHandler.tft = self
            server = HTTPServer(("", WebHandler.port), WebHandler)
            server.serve_forever()
